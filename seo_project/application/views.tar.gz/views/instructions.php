<p>
Everywhere you can use the following
tags: <br>
<b>special for this subdomain:</b>
%city%, %state%,
%trade%, %subtrade1%, %subtrade2%, ...
%subtrade<i>N</i>%, where <i>N</i> >=1;

%subtrades% or %sub-trades% -- comma-separated
list of all subtrades;

%cities% -- comma-separated list of all
cities;

%trades% -- comma-separated list of all
trades;


%name% -- subdomain name,
%img1% -- main uploaded image,
%img2% -- second uploaded image,
%img3% -- third uploaded image,
<br>
<b> common for every subdomain:</b>
%company%,
%domain%,
%maincity%,

%metatitle%,
%metakeywords%,
%metadescription%,
%pagetitle%,
%subdomaincontent%,
%tradecontent%,

%templatetitle%,
%templatekeywords%,
%templatedescription%,
%templatecontent%.
</p>
