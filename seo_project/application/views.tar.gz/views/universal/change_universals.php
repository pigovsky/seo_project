<?
    require_once 'application/views/tinymceload.php';
?>
<script language="javascript" type="text/javascript">
	runTinyMCE("u_universalcontent");
</script>

<? echo form_open('subdomain/changing_universals'); ?>
<p> Values, which are common for every subdomain: </p>
<table>
<? foreach ($universal as $key => $value) : ?>
	<tr>
		<td><? echo $key; ?>:</td>
		<td> 
		<? if (strlen($value)>30) : ?>
			<textarea rows="10" cols="45" id="u_<? echo $key; ?>" name="<? echo $key; ?>" ><? echo $value; ?></textarea>
		<? else : ?>
			<input type="text" name="<? echo $key; ?>" value="<? echo $value; ?>">
		<? endif; ?> 
		</td>
	</tr>
<? endforeach; ?>
</table>
<p> <input type="submit" value="update"> </p>
</form>
<p> 
		Everywhere you can use the following
		tags: <br>
		<b>special for the current subdomain:</b>
		%city%, %state%, 
		%trade%, %subtrade1%, %subtrade2%, ...
		%subtrade<i>N</i>%, where <i>N</i> >=1,
		
		%name% -- subdomain name,
		%img1% -- main image name in "/img" folder,
		%img2% -- second image name in "/img" folder,
		%img3% -- third image name in "/img" folder,
		 <br>		
		<b> common for every subdomain:</b>
		%company%, 
		%domain%, 
		%maincity%,
		%universaltitle%,
		%universalkeywords%,
		%universaldescription%,
		%universalbody%.
	</p>
